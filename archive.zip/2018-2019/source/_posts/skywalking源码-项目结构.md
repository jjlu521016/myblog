---
title: skywalking源码-项目结构
tags:
  - skywalking
toc: true
originContent: |-
  > 说明 基于skywalking最新的6.x版本
  [官网地址](http://skywalking.apache.org/)
categories:
  - 链路追踪
date: 2019-03-21 13:36:32
---

> 说明 基于skywalking最新的6.x版本
[官网地址](http://skywalking.apache.org/)
[github地址](https://github.com/apache/incubator-skywalking)